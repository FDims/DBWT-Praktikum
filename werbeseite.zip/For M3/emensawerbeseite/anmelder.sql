create table anmelder
(
    name    varchar(200) null,
    email   varchar(200) null,
    sprache char(8)      null,
    id      int auto_increment
        primary key
);

