create table allergen
(
    code char(4)      not null
        primary key,
    name varchar(800) not null,
    typ  varchar(20)  not null
);

