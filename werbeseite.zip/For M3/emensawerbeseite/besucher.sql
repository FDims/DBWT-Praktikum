create table besucher
(
    counter int null
);

