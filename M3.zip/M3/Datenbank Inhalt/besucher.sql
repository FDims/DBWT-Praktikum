INSERT INTO emensawerbeseite.besucher (counter) VALUES (3);
